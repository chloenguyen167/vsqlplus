# Ket qua thuc nghiem V-SQL

So cau hoi chung cho moi cau hinh: **498**

## 1. Execution Accuracy (EX, %)

| Cau hinh | Mo ta | Simple | Moderate | Challenging | Tong | CI 95% |
|---|---|---|---|---|---|---|
| `base` | Baseline 1 giai doan tren bang goc | 59.5 (n=148) | 41.1 (n=248) | 39.2 (n=102) | **46.2** | [41.8, 50.6] |
| `vsql` | TAI HIEN PAPER: view theo dap an + LLM tai tao | 52.0 (n=148) | 37.5 (n=248) | 33.3 (n=102) | **41.0** | [36.5, 45.6] |
| `auto_det` | CT1+CT2 | 43.2 (n=148) | 33.9 (n=248) | 35.3 (n=102) | **36.9** | [32.5, 41.2] |
| `hybrid` | CT1+CT2+CT3: schema lai | 49.3 (n=148) | 35.1 (n=248) | 28.4 (n=102) | **38.0** | [33.5, 42.2] |
| `hybrid_ret` | CT1+2+3+CT4: truy xuat view | 47.3 (n=148) | 33.9 (n=248) | 23.5 (n=102) | **35.7** | [31.7, 40.0] |
| `auto_det_fix` | CT1+CT2 + CT5 schema-guard | 52.0 (n=148) | 37.9 (n=248) | 38.2 (n=102) | **42.2** | [37.8, 46.4] |
| `base_fix` | Baseline 1 giai doan tren bang goc + CT5 schema-guard | 60.1 (n=148) | 44.0 (n=248) | 45.1 (n=102) | **49.0** | [44.6, 53.2] |
| `hybrid_fix` | CT1+CT2+CT3: schema lai + CT5 schema-guard | 56.1 (n=148) | 39.9 (n=248) | 39.2 (n=102) | **44.6** | [40.2, 48.8] |
| `hybrid_ret_fix` | CT1+2+3+CT4: truy xuat view + CT5 schema-guard | 57.4 (n=148) | 38.7 (n=248) | 36.3 (n=102) | **43.8** | [39.6, 48.0] |
| `mrv` | CT7 bo phieu theo ket qua thuc thi | 61.5 (n=148) | 44.4 (n=248) | 45.1 (n=102) | **49.6** | [45.2, 53.8] |
| `vsql_fix` | TAI HIEN PAPER: view theo dap an + LLM tai tao + CT5 schema-guard | 54.1 (n=148) | 39.5 (n=248) | 39.2 (n=102) | **43.8** | [39.6, 48.4] |

## 2a. So sanh ghep cap voi `vsql` (phuong phap cua paper)

| Cau hinh | dEX (diem %) | CI 95% cua dEX | Chi ref dung | Chi cau hinh nay dung | p McNemar | p Holm |
|---|---|---|---|---|---|---|
| `base` | +5.2 | [+0.8, +9.4] | 48 | 74 | 0.023 | 0.139 |
| `auto_det` | -4.0 | [-8.0, -0.2] | 60 | 40 | 0.057 | 0.284 |
| `hybrid` | -3.0 | [-7.2, +1.0] | 58 | 43 | 0.163 | 0.490 |
| `hybrid_ret` | -5.2 | [-9.2, -1.4] | 62 | 36 | 0.011 | 0.078 |
| `auto_det_fix` | +1.2 | [-2.8, +5.0] | 45 | 51 | 0.610 | 0.610 |
| `base_fix` | +8.0 | [+3.4, +12.2] | 42 | 82 | 0.000 | **0.004** |
| `hybrid_fix` | +3.6 | [-0.2, +7.2] | 36 | 54 | 0.073 | 0.290 |
| `hybrid_ret_fix` | +2.8 | [-1.2, +6.8] | 43 | 57 | 0.193 | 0.490 |
| `mrv` | +8.6 | [+4.6, +12.4] | 29 | 72 | 0.000 | **0.000** |
| `vsql_fix` | +2.8 | [+1.2, +4.4] | 1 | 15 | 0.001 | **0.004** |

## 2b. So sanh ghep cap voi `base` (baseline 1 giai doan)

| Cau hinh | dEX (diem %) | CI 95% cua dEX | Chi ref dung | Chi cau hinh nay dung | p McNemar | p Holm |
|---|---|---|---|---|---|---|
| `vsql` | -5.2 | [-9.4, -0.8] | 74 | 48 | 0.023 | 0.139 |
| `auto_det` | -9.2 | [-13.5, -4.8] | 87 | 41 | 0.000 | **0.001** |
| `hybrid` | -8.2 | [-12.0, -4.2] | 74 | 33 | 0.000 | **0.001** |
| `hybrid_ret` | -10.4 | [-14.5, -6.2] | 87 | 35 | 0.000 | **0.000** |
| `auto_det_fix` | -4.0 | [-8.2, +0.2] | 68 | 48 | 0.077 | 0.309 |
| `base_fix` | +2.8 | [+1.4, +4.4] | 1 | 15 | 0.001 | **0.004** |
| `hybrid_fix` | -1.6 | [-5.2, +2.2] | 51 | 43 | 0.470 | 0.856 |
| `hybrid_ret_fix` | -2.4 | [-6.2, +1.6] | 59 | 47 | 0.285 | 0.856 |
| `mrv` | +3.4 | [+0.2, +6.4] | 26 | 43 | 0.053 | 0.266 |
| `vsql_fix` | -2.4 | [-6.6, +2.0] | 66 | 54 | 0.315 | 0.856 |

p < 0.05 moi coi la khac biet co y nghia thong ke; p Holm da hieu chinh cho nhieu phep so sanh trong cung bang.

## 3. Phan loai ket qua sai (% tren tong so cau)

`schema_column` + `schema_table` + `ambiguous_column` = ao giac schema (dieu paper muon giam).

| Cau hinh | schema_column | schema_table | ambiguous_column | syntax | no_sql | timeout | other_exec | wrong_empty | wrong_result | **Ao giac schema** |
|---|---|---|---|---|---|---|---|---|---|---|
| `base` | 8.0 | 0.0 | 0.4 | 1.8 | 0.0 | 0.4 | 1.0 | 6.2 | 35.9 | **8.4** |
| `vsql` | 11.2 | 0.0 | 1.8 | 0.8 | 0.0 | 0.4 | 1.2 | 4.6 | 39.0 | **13.1** |
| `auto_det` | 16.7 | 0.0 | 0.0 | 1.0 | 0.0 | 0.8 | 2.0 | 5.6 | 36.9 | **16.7** |
| `hybrid` | 19.7 | 0.2 | 0.4 | 1.2 | 0.0 | 0.4 | 0.8 | 4.6 | 34.7 | **20.3** |
| `hybrid_ret` | 20.3 | 0.2 | 0.4 | 1.8 | 0.0 | 0.0 | 0.8 | 5.2 | 35.5 | **20.9** |
| `auto_det_fix` | 2.6 | 0.0 | 0.0 | 1.0 | 0.0 | 0.8 | 1.4 | 7.0 | 45.0 | **2.6** |
| `base_fix` | 1.0 | 0.0 | 0.4 | 1.8 | 0.0 | 0.4 | 0.8 | 7.0 | 39.6 | **1.4** |
| `hybrid_fix` | 1.8 | 0.0 | 0.0 | 1.4 | 0.0 | 0.4 | 0.6 | 6.4 | 44.8 | **1.8** |
| `hybrid_ret_fix` | 2.6 | 0.2 | 0.0 | 1.8 | 0.0 | 0.0 | 0.6 | 7.0 | 44.0 | **2.8** |
| `mrv` | 0.2 | 0.0 | 0.0 | 0.4 | 0.0 | 0.0 | 0.4 | 3.2 | 46.2 | **0.2** |
| `vsql_fix` | 1.4 | 0.0 | 0.2 | 0.8 | 0.0 | 0.4 | 1.2 | 6.4 | 45.8 | **1.6** |

## 4. Chi phi (trung binh moi cau)

| Cau hinh | So lan goi LLM | Token vao | Token ra | Giay LLM | So doi tuong schema | Do phu bang dap an | VES xap xi |
|---|---|---|---|---|---|---|---|
| `base` | 1.00 | 2577 | 68 | 3.9 | 7.3 | 100.0 | 61.9 |
| `vsql` | 1.98 | 7782 | 145 | 8.4 | 5.0 | 100.0 | 46.7 |
| `auto_det` | 1.00 | 5145 | 59 | 3.7 | 4.7 | 100.0 | 44.6 |
| `hybrid` | 1.00 | 5950 | 65 | 4.4 | 11.2 | 100.0 | 40.2 |
| `hybrid_ret` | 1.00 | 4416 | 62 | 4.2 | 4.9 | 98.8 | 47.0 |
| `auto_det_fix` | 1.00 | 5145 | 59 | 3.7 | 4.7 | 100.0 | 51.0 |
| `base_fix` | 1.00 | 2577 | 68 | 3.9 | 7.3 | 100.0 | 60.4 |
| `hybrid_fix` | 1.00 | 5950 | 65 | 4.4 | 11.2 | 100.0 | 48.3 |
| `hybrid_ret_fix` | 1.00 | 4416 | 62 | 4.2 | 4.9 | 98.8 | 52.4 |
| `mrv` | 4.00 | 18089 | 254 | 16.2 | 6.7 | 100.0 | 60.2 |
| `vsql_fix` | 1.98 | 7782 | 145 | 8.4 | 5.0 | 100.0 | 46.4 |

- *Do phu bang dap an*: ti le cau ma moi bang trong SQL dap an deu nam trong schema dua cho LLM (< 100% o `hybrid_ret` la loi cua buoc truy xuat).
- *VES xap xi*: sqrt(t_dap_an / t_du_doan) tren cau dung, do 1 lan chay nen chi mang tinh tham khao.

## 5. Dong gop rieng cua tung cai tien

| Yeu to | So sanh | dEX |
|---|---|---|
| CT3 schema lai (them bang goc) | `hybrid` - `auto_det` | +1.0 |
| CT4 truy xuat top-k | `hybrid_ret` - `hybrid` | -2.2 |
| Dong gop cua view so voi baseline 1 giai doan | `vsql` - `base` | -5.2 |

## 6. Thong ke view

| DB | Bang | FK | View oracle (trong do co nhan ban dong) | View auto | View auto giu nguyen so dong |
|---|---|---|---|---|---|
| california_schools | 3 | 2 | 2 (0) | 1 | 1 |
| card_games | 6 | 4 | 4 (0) | 1 | 1 |
| codebase_community | 8 | 13 | 7 (0) | 7 | 7 |
| debit_card_specializing | 5 | 1 | 1 (0) | 1 | 1 |
| european_football_2 | 7 | 31 | 3 (0) | 3 | 3 |
| financial | 8 | 8 | 10 (3) | 7 | 7 |
| formula_1 | 13 | 19 | 8 (0) | 8 | 8 |
| student_club | 8 | 8 | 6 (1) | 5 | 5 |
| superhero | 10 | 11 | 3 (0) | 3 | 3 |
| thrombosis_prediction | 3 | 2 | 3 (1) | 2 | 2 |
| toxicology | 4 | 5 | 4 (1) | 3 | 3 |
